import React from "react";
import Table from "../../UI/Table";
import FormExamCommittee from "./FormExamCommittee";

const Chairman = () => {
  return <div className="w-full h-full">
    <FormExamCommittee></FormExamCommittee>
  </div>;
};

export default Chairman;
